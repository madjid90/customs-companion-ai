import { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { Mail, ArrowRight, Loader2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Logo } from "@/components/ui/Logo";
import { Label } from "@/components/ui/label";
import { useAppAuth } from "@/hooks/useAppAuth";
import { useToast } from "@/hooks/use-toast";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, setSessionFromOtp } = useAppAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (isAuthenticated) {
      const from = location.state?.from?.pathname || "/app/chat";
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, navigate, location]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/verify-otp`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          skipOtp: true,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Erreur de connexion");
        setIsLoading(false);
        return;
      }

      await setSessionFromOtp(
        {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
        },
        data.user
      );

      toast({
        title: "Connexion réussie !",
        description: `Bienvenue ${data.user.display_name || ""}`,
      });

      navigate("/app/chat");
    } catch (err) {
      setError("Erreur de connexion au serveur");
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center page-gradient p-4 overflow-auto">
      {/* Back button */}
      <div className="w-full max-w-md mb-4 md:mb-6 flex-shrink-0">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center justify-center h-10 w-10 rounded-xl border border-border/50 bg-card text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
      </div>

      <Card className="w-full max-w-md card-elevated border border-border/20 rounded-3xl overflow-hidden flex-shrink-0">
        <CardContent className="p-6 md:p-10">
          {/* Header */}
          <div className="text-center mb-5 md:mb-8">
            <div className="mx-auto mb-3 md:mb-5">
              <Logo size="lg" />
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight mb-2">
              Me connecter
            </h1>
            <p className="text-sm text-muted-foreground">
              Accédez à votre espace membre
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2 text-sm font-semibold">
                <Mail className="h-4 w-4 text-primary" />
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                autoFocus
                required
              />
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-destructive/10 text-destructive text-sm">
                {error}
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-14 cta-gradient rounded-2xl text-base font-semibold gap-2"
              disabled={isLoading || !email.trim()}
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Connexion...
                </>
              ) : (
                <>
                  Me connecter
                  <ArrowRight className="h-5 w-5" />
                </>
              )}
            </Button>

            <div className="text-center pt-2">
              <p className="text-sm text-muted-foreground">
                Pas encore de compte ?{" "}
                <Link to="/demander-acces" className="text-primary font-medium hover:underline">
                  Demander l'accès
                </Link>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}