// ============================================================================
// EDGE FUNCTION: CONSULTATION REPORT
// ============================================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { getCorsHeaders, handleCorsPreFlight } from "../_shared/cors.ts";
import { requireAuth } from "../_shared/auth-check.ts";
import { fetchWithRetry, RETRY_CONFIGS } from "../_shared/retry.ts";
import { calculateCAF, calculateTaxes, EXCHANGE_RATES, type TaxBreakdown } from "./tax-calculator.ts";
import {
  buildImportReportPrompt,
  buildMREReportPrompt,
  buildConformityReportPrompt,
  buildInvestorReportPrompt,
} from "./prompts.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
const LOVABLE_AI_GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const LOVABLE_AI_MODEL = "google/gemini-2.5-flash";

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return handleCorsPreFlight(req);
  const corsHeaders = getCorsHeaders(req);

  try {
    const authResult = await requireAuth(req);
    if (authResult.error) {
      return new Response(JSON.stringify({ error: "Non autorisé" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "Configuration manquante" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { type, inputs } = body;
    const startTime = Date.now();

    // =========================================================================
    // EXTRACT & ANALYZE UPLOADED FILES
    // =========================================================================
    const uploadedFiles = inputs._files || [];
    delete inputs._files;

    let fileContext = "";

    if (uploadedFiles.length > 0 && LOVABLE_API_KEY) {
      for (const f of uploadedFiles) {
        if (f.type === "image" && f.base64) {
          try {
            console.log("Analyzing image for consultation...");
            const imageAnalysis = await analyzeFileWithAI(
              f.base64,
              "image",
              f.file?.type || "image/jpeg",
              "Identifie le produit, extrais la description, le code SH si visible, la valeur, le pays d'origine, l'incoterm."
            );
            fileContext += `\n\n## ANALYSE IMAGE\n${imageAnalysis}\n`;
          } catch (err) {
            console.error("Image analysis error:", err);
          }
        } else if (f.type === "pdf" && f.base64) {
          try {
            console.log("Analyzing PDF for consultation...");
            const pdfAnalysis = await analyzeFileWithAI(
              f.base64,
              "pdf",
              "application/pdf",
              "Extrais TOUTES les informations utiles pour un rapport douanier: description produit, code SH, valeur, devise, incoterm, pays d'origine, poids, quantité."
            );
            fileContext += `\n\n## ANALYSE PDF\n${pdfAnalysis}\n`;
          } catch (err) {
            console.error("PDF analysis error:", err);
          }
        }
      }
      if (fileContext) {
        console.log(`File analysis context: ${fileContext.length} chars`);
      }
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Generate reference
    const { data: refData } = await supabase.rpc("generate_consultation_ref", { type });
    const reference = refData || `CONS-${Date.now()}`;

    // Get phone_user_id
    const userId = authResult.user?.id;
    let phoneUserId = null;
    if (userId) {
      const { data: phoneUser } = await supabase
        .from("phone_users")
        .select("id")
        .eq("auth_user_id", userId)
        .maybeSingle();
      phoneUserId = phoneUser?.id || null;
    }

    // Save initial record
    const { data: consultation, error: insertError } = await supabase
      .from("consultations")
      .insert({
        reference,
        user_id: phoneUserId,
        consultation_type: type,
        inputs,
        status: "processing",
      })
      .select("id")
      .single();

    if (insertError) {
      console.error("Insert error:", insertError);
    }

    // =========================================================================
    // DISPATCH BY TYPE
    // =========================================================================
    let report: any;
    let confidence: string = "medium";

    try {
      switch (type) {
        case "import":
          report = await processImportReport(supabase, inputs, fileContext);
          break;
        case "mre":
          report = await processMREReport(supabase, inputs, fileContext);
          break;
        case "conformity":
          report = await processConformityReport(supabase, inputs, fileContext);
          break;
        case "investor":
          report = await processInvestorReport(supabase, inputs, fileContext);
          break;
        default:
          throw new Error(`Type inconnu: ${type}`);
      }

      confidence = report?.classification?.confidence || "medium";
    } catch (processError: any) {
      console.error("Process error:", processError);
      if (consultation?.id) {
        await supabase.from("consultations").update({
          status: "error",
          error_message: processError.message,
          processing_time_ms: Date.now() - startTime,
        }).eq("id", consultation.id);
      }
      return new Response(JSON.stringify({ error: processError.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const processingTime = Date.now() - startTime;
    if (consultation?.id) {
      await supabase.from("consultations").update({
        report,
        status: "completed",
        confidence,
        processing_time_ms: processingTime,
      }).eq("id", consultation.id);
    }

    return new Response(JSON.stringify({
      reference,
      date: new Date().toLocaleDateString("fr-MA", { day: "2-digit", month: "2-digit", year: "numeric" }),
      type,
      confidence,
      processing_time_ms: processingTime,
      report,
    }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("Unhandled error:", error);
    return new Response(JSON.stringify({ error: "Erreur interne" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// ============================================================================
// FILE ANALYSIS HELPER
// ============================================================================
async function analyzeFileWithAI(base64: string, fileType: string, mimeType: string, instruction: string): Promise<string> {
  const content: any[] = [];
  
  if (fileType === "image") {
    content.push({
      type: "image_url",
      image_url: { url: `data:${mimeType};base64,${base64}` },
    });
  } else if (fileType === "pdf") {
    content.push({
      type: "image_url",
      image_url: { url: `data:application/pdf;base64,${base64}` },
    });
  }
  
  content.push({ type: "text", text: instruction });

  const response = await fetch(LOVABLE_AI_GATEWAY, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: LOVABLE_AI_MODEL,
      max_tokens: 2048,
      messages: [{ role: "user", content }],
    }),
  });

  if (!response.ok) throw new Error(`AI analysis error: ${response.status}`);
  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

// ============================================================================
// IMPORT STANDARD PROCESSOR
// ============================================================================
async function processImportReport(supabase: any, inputs: any, fileContext: string = "") {
  const {
    product_description, hs_code, country_code,
    value, currency, incoterm, freight, insurance,
    regime, agreement, sections = [],
  } = inputs;

  // 1. Fetch tariff data from DB — cascade: exact code → 6-digit → circular → keyword
  let tariffContext = "";
  let dutyRate = 25;
  let vatRate = 20;
  let tariffFound = false;
  let tariffSource = "default";

  if (hs_code) {
    const cleanCode = hs_code.replace(/[.\s-]/g, "");
    const code6 = cleanCode.substring(0, 6);

    // Step 1a: Exact national_code match (droit commun — no agreement_code)
    const { data: exactTariffs } = await supabase
      .from("country_tariffs")
      .select("*")
      .eq("country_code", country_code || "MA")
      .eq("national_code", cleanCode)
      .is("agreement_code", null)
      .eq("is_active", true)
      .limit(5);

    if (exactTariffs?.length > 0) {
      dutyRate = exactTariffs[0].duty_rate ?? 25;
      vatRate = exactTariffs[0].vat_rate ?? 20;
      tariffFound = true;
      tariffSource = exactTariffs[0].source || "tariff";
      tariffContext = exactTariffs.map((t: any) =>
        `Code: ${t.national_code} | Désignation: ${t.description_local} | DI: ${t.duty_rate}% | TVA: ${t.vat_rate}% | Source: ${t.source || "tarif"}`
      ).join("\n");
    }

    // Step 1b: 6-digit prefix match (droit commun)
    if (!tariffFound) {
      const { data: prefixTariffs } = await supabase
        .from("country_tariffs")
        .select("*")
        .eq("country_code", country_code || "MA")
        .eq("hs_code_6", code6)
        .is("agreement_code", null)
        .eq("is_active", true)
        .limit(5);

      if (prefixTariffs?.length > 0) {
        dutyRate = prefixTariffs[0].duty_rate ?? 25;
        vatRate = prefixTariffs[0].vat_rate ?? 20;
        tariffFound = true;
        tariffSource = prefixTariffs[0].source || "tariff";
        tariffContext = prefixTariffs.map((t: any) =>
          `Code: ${t.national_code || t.hs_code_6} | Désignation: ${t.description_local} | DI: ${t.duty_rate}% | TVA: ${t.vat_rate}% | Source: ${t.source || "tarif"}`
        ).join("\n");
      }
    }

    // Step 1c: TOUJOURS chercher les circulaires — elles PRIMENT sur le tarif de base
    {
      const { data: circularTariffs } = await supabase
        .from("country_tariffs")
        .select("*")
        .eq("country_code", country_code || "MA")
        .or(`national_code.eq.${cleanCode},hs_code_6.eq.${code6}`)
        .eq("source", "circular")
        .eq("is_active", true)
        .limit(5);

      if (circularTariffs?.length > 0) {
        const circRate = circularTariffs[0].duty_rate;
        if (circRate !== null && circRate !== undefined) {
          if (circRate !== dutyRate) {
            console.log(`Circulaire modifie le DDI: ${dutyRate}% → ${circRate}%`);
            tariffContext += `\n⚠️ CIRCULAIRE MODIFICATIVE: DI modifié de ${dutyRate}% → ${circRate}%`;
          }
          dutyRate = circRate;
          vatRate = circularTariffs[0].vat_rate ?? vatRate;
          tariffFound = true;
          tariffSource = "circular";
        }
        tariffContext += "\n" + circularTariffs.map((t: any) =>
          `Code: ${t.national_code || t.hs_code_6} | Désignation: ${t.description_local} | DI: ${t.duty_rate}% | TVA: ${t.vat_rate}% | Source: circulaire | Accord: ${t.agreement_code || "N/A"}`
        ).join("\n");
      }
    }
  }

  // Step 1d: Keyword fallback
  if (!tariffFound && product_description) {
    const keywords = product_description.split(/\s+/).filter((w: string) => w.length > 3).slice(0, 3);
    for (const kw of keywords) {
      const { data } = await supabase
        .from("country_tariffs")
        .select("*")
        .eq("country_code", country_code || "MA")
        .ilike("description_local", `%${kw}%`)
        .is("agreement_code", null)
        .eq("is_active", true)
        .limit(5);
      if (data?.length > 0) {
        if (!tariffFound) {
          dutyRate = data[0].duty_rate ?? 25;
          vatRate = data[0].vat_rate ?? 20;
          tariffFound = true;
          tariffSource = data[0].source || "keyword";
        }
        tariffContext += data.map((t: any) =>
          `Code: ${t.national_code || t.hs_code_6} | Désignation: ${t.description_local} | DI: ${t.duty_rate}% | TVA: ${t.vat_rate}% | Source: ${t.source || "tarif"}`
        ).join("\n") + "\n";
      }
    }
  }

  console.log(`Tariff lookup: found=${tariffFound}, dutyRate=${dutyRate}%, vatRate=${vatRate}%, source=${tariffSource}`);

  // ⚠️ Alerter quand le taux est un défaut arbitraire
  if (!tariffFound) {
    console.warn(`⚠️ No tariff found for ${hs_code}, using default ${dutyRate}%`);
    tariffContext += "\n⚠️ ATTENTION : Aucun taux trouvé en base de données pour ce code SH. Le taux de 25% est utilisé par DÉFAUT — vérifier le tarif officiel sur BADR ou www.douane.gov.ma.";
  }

  // 2. Fetch controlled products
  let controlledContext = "";
  const codePrefix = hs_code ? hs_code.replace(/[.\s-]/g, "").substring(0, 4) : "";
  if (codePrefix) {
    const { data: controlled } = await supabase
      .from("controlled_products")
      .select("*")
      .eq("country_code", country_code || "MA")
      .ilike("hs_code", `${codePrefix}%`)
      .eq("is_active", true);
    if (controlled?.length) {
      controlledContext = controlled.map((c: any) =>
        `HS: ${c.hs_code} | Contrôle: ${c.control_type} | Autorité: ${c.control_authority} | Documents: ${JSON.stringify(c.required_documents)}`
      ).join("\n");
    }
  }

  // 2b. Si ANRT requis, vérifier si le produit est déjà homologué ou dispensé
  let anrtContext = "";
  if (controlledContext.includes("ANRT") && product_description) {
    try {
      // Search approved equipment
      const { data: anrtResults } = await supabase
        .rpc("search_anrt_equipment", {
          p_query: product_description,
          p_limit: 5,
        });

      // Search dispensed equipment
      const { data: dispensedResults } = await supabase
        .rpc("search_anrt_dispensed_equipment", {
          search_query: product_description,
          max_results: 5,
        });

      if (anrtResults?.length) {
        anrtContext = `\n\n🔍 ÉQUIPEMENTS ANRT HOMOLOGUÉS (AGRÉÉS):\n`;
        anrtContext += anrtResults.map((r: any) =>
          `- ✅ ${r.designation} | Marque: ${r.brand} | Type: ${r.type_ref} | Modèle: ${r.model || 'N/A'} | Agrément: ${r.approval_number}`
        ).join("\n");
        anrtContext += `\nSi le produit correspond, l'homologation ANRT est DÉJÀ OBTENUE.`;
      }

      if (dispensedResults?.length) {
        anrtContext += `\n\n🔓 ÉQUIPEMENTS DISPENSÉS D'HOMOLOGATION ANRT:\n`;
        anrtContext += dispensedResults.map((r: any) =>
          `- 🔓 ${r.designation} | Marque: ${r.brand || 'N/A'} | Type/Modèle: ${r.type_model || 'N/A'} | Dispense: ${r.dispensation_number || 'N/A'}`
        ).join("\n");
        anrtContext += `\nCes équipements sont DISPENSÉS — aucune homologation ANRT requise pour l'import.`;
      }

      if (!anrtResults?.length && !dispensedResults?.length) {
        anrtContext = `\n\n🔍 VÉRIFICATION ANRT: Aucun équipement correspondant trouvé dans les 41 000+ agréments ni les 40 000+ dispenses. Une demande d'homologation ANRT sera nécessaire AVANT l'importation.`;
      }
    } catch (err) {
      console.error("ANRT search error:", err);
    }
  }

  // 3. Fetch legal chunks
  let legalContext = "";
  if (product_description) {
    const keywords = product_description.split(/\s+/).filter((w: string) => w.length > 3).slice(0, 3);
    for (const kw of keywords) {
      const { data: chunks } = await supabase
        .from("legal_chunks")
        .select("chunk_text, source_id")
        .ilike("chunk_text", `%${kw}%`)
        .limit(3);
      if (chunks?.length) {
        legalContext += chunks.map((c: any) => c.chunk_text.substring(0, 500)).join("\n\n");
      }
    }
  }

  // 3b. Fetch TIC rates
  let ticRate = 0;
  if (hs_code) {
    const cleanCode = hs_code.replace(/[.\s-]/g, "");
    const { data: ticData } = await supabase
      .from("tic_rates")
      .select("*")
      .eq("is_active", true);
    if (ticData?.length) {
      for (const tic of ticData) {
        if (cleanCode.startsWith(tic.hs_code_pattern.replace(/[.\s-]/g, ""))) {
          if (tic.tic_type === "ad_valorem" && tic.tic_rate) {
            ticRate = parseFloat(tic.tic_rate) * 100;
          }
          break;
        }
      }
    }
  }

  // 3c. Fetch required import documents
  let documentsContext = "";
  const { data: importDocs } = await supabase
    .from("import_documents")
    .select("*")
    .eq("is_active", true)
    .order("sort_order");
  if (importDocs?.length) {
    documentsContext = importDocs.map((d: any) =>
      `📄 ${d.document_name_fr} | Catégorie: ${d.category} | Requis: ${d.when_required || "Toujours"} | ${d.description_fr || ""}`
    ).join("\n");
  }

  // 4. Calculate taxes
  const exchangeRate = EXCHANGE_RATES[currency] || 10;
  const cafResult = calculateCAF({
    value: parseFloat(value) || 0,
    currency,
    incoterm: incoterm || "FOB",
    freight: freight ? parseFloat(freight) : undefined,
    insurance: insurance ? parseFloat(insurance) : undefined,
    exchange_rate: exchangeRate,
  });

  // 4b. Lookup preferential rate from country_tariffs with matching agreement_code
  let preferentialDutyRate: number | null = null;
  let agreementName = "";
  let proofRequired = "";
  let agreementReduction = 0;

  if (agreement && agreement !== "none") {
    // First get the agreement info
    const { data: agreements } = await supabase
      .from("trade_agreements")
      .select("*")
      .eq("code", agreement)
      .eq("is_active", true)
      .limit(1);

    if (agreements?.length) {
      agreementName = agreements[0].name_fr || "";
      proofRequired = agreements[0].proof_required || "";

      // Search for a preferential tariff line for this specific HS code + agreement
      if (hs_code) {
        const cleanCode = hs_code.replace(/[.\s-]/g, "");
        const code6 = cleanCode.substring(0, 6);

        const { data: prefTariffs } = await supabase
          .from("country_tariffs")
          .select("duty_rate, national_code, description_local")
          .eq("country_code", country_code || "MA")
          .eq("agreement_code", agreement)
          .or(`national_code.eq.${cleanCode},hs_code_6.eq.${code6}`)
          .eq("is_active", true)
          .limit(1);

        if (prefTariffs?.length > 0) {
          preferentialDutyRate = prefTariffs[0].duty_rate ?? 0;
          // Calculate reduction as fraction: (base - pref) / base
          if (dutyRate > 0) {
            agreementReduction = (dutyRate - preferentialDutyRate) / dutyRate;
          } else {
            agreementReduction = 0;
          }
          console.log(`Preferential tariff found: ${agreement} → ${preferentialDutyRate}% (base: ${dutyRate}%, reduction: ${(agreementReduction * 100).toFixed(1)}%)`);
          tariffContext += `\n\nTARIF PRÉFÉRENTIEL (${agreementName}):\nCode: ${prefTariffs[0].national_code} | DI préférentiel: ${preferentialDutyRate}% (au lieu de ${dutyRate}%) | Preuve: ${proofRequired}`;
        } else {
          // No specific preferential rate found for this code — check if agreement grants general exoneration
          if (agreements[0].preferential_duty_rate != null) {
            preferentialDutyRate = agreements[0].preferential_duty_rate;
            agreementReduction = dutyRate > 0 ? (dutyRate - preferentialDutyRate) / dutyRate : 0;
          }
          console.log(`No preferential tariff line found for ${agreement} + code ${hs_code}. Using agreement-level rate: ${preferentialDutyRate}`);
        }
      }
    }
  }

  const taxes = calculateTaxes({
    caf_mad: cafResult.caf_mad,
    duty_rate: dutyRate,
    vat_rate: vatRate,
    tic_rate: ticRate,
    agreement_reduction: agreementReduction > 0 ? agreementReduction : 0,
  });

  // 5. Call LLM
  const fullContext = [legalContext, fileContext, documentsContext ? `\n## DOCUMENTS D'IMPORTATION REQUIS\n${documentsContext}` : ""].join("\n");
  const prompt = buildImportReportPrompt(
    product_description, hs_code, country_code || "MA",
    tariffContext, controlledContext + anrtContext, fullContext, sections
  );
  const aiReport = await callLLM(prompt);

  return {
    ...aiReport,
    taxes: {
      caf_details: cafResult.details,
      caf_value_mad: cafResult.caf_mad,
      exchange_rate: exchangeRate,
      currency,
      tariff_from_db: tariffFound,
      tariff_source: tariffSource,
      tariff_is_default: !tariffFound,
      duty_rate: dutyRate,
      vat_rate: vatRate,
      preferential_duty_rate: preferentialDutyRate,
      agreement_name: agreementName || undefined,
      proof_required: proofRequired || undefined,
      ...taxes,
    },
    input_summary: {
      product: product_description,
      hs_code: hs_code || aiReport?.classification?.hs_code || "Non déterminé",
      country: country_code,
      value: `${value} ${currency} ${incoterm}`,
      regime,
      agreement,
    },
  };
}

// ============================================================================
// MRE PROCESSOR
// ============================================================================
async function processMREReport(supabase: any, inputs: any, fileContext: string = "") {
  const {
    import_type, vehicle_brand, vehicle_year, vehicle_fuel, vehicle_cc,
    vehicle_value, vehicle_currency, vehicle_ownership_months,
    effects_description, effects_value, effects_transport,
    residence_country, residence_years, return_type,
    has_carte_sejour, has_certificat_residence, has_certificat_changement,
  } = inputs;

  const { data: rules } = await supabase.from("mre_rules").select("*").eq("is_active", true);

  // Format MRE rules for context
  let rulesContext = "";
  if (rules?.length) {
    rulesContext = "\n\n## RÈGLES MRE (BASE DE DONNÉES)\n" + rules.map((r: any) =>
      `- ${r.rule_type} | ${r.condition_key}: ${r.condition_value} | ${r.description_fr || ""} | Réf: ${r.legal_reference || "N/A"}`
    ).join("\n");
  }

  let legalContext = "";
  const { data: chunks } = await supabase
    .from("legal_chunks")
    .select("chunk_text, source_id")
    .or("chunk_text.ilike.%MRE%,chunk_text.ilike.%retour définitif%,chunk_text.ilike.%abattement%,chunk_text.ilike.%article 164%")
    .limit(5);
  if (chunks?.length) {
    legalContext = chunks.map((c: any) => c.chunk_text.substring(0, 500)).join("\n\n");
  }

  // Fetch MRE-related documents
  let documentsContext = "";
  const { data: mreDocs } = await supabase
    .from("import_documents")
    .select("*")
    .eq("is_active", true)
    .or("applies_to.ilike.%mre%,applies_to.ilike.%all%,category.eq.mre");
  if (mreDocs?.length) {
    documentsContext = "\n\n## DOCUMENTS REQUIS (DB)\n" + mreDocs.map((d: any) =>
      `📄 ${d.document_name_fr} | ${d.when_required || "Toujours"} | ${d.description_fr || ""}`
    ).join("\n");
  }

  let vehicleTaxes: TaxBreakdown | null = null;
  let vehicleTaxesWithout: TaxBreakdown | null = null;

  if (import_type === "vehicle" || import_type === "both") {
    const vValue = parseFloat(vehicle_value) || 0;
    const vCurrency = vehicle_currency || "EUR";
    const exchangeRate = EXCHANGE_RATES[vCurrency] || 10;
    const caf_mad = Math.ceil(vValue * exchangeRate);

    // Lookup vehicle duty rate from country_tariffs (chapter 87 = vehicles)
    let vehicleDutyRate = 17.5;
    if (vehicle_fuel === "electrique") {
      vehicleDutyRate = 2.5;
    } else {
      // Try to find actual duty rate for vehicles in DB
      const { data: vehicleTariff } = await supabase
        .from("country_tariffs")
        .select("duty_rate")
        .eq("country_code", "MA")
        .ilike("hs_code_6", "8703%")
        .eq("is_active", true)
        .limit(1);
      if (vehicleTariff?.[0]) vehicleDutyRate = vehicleTariff[0].duty_rate ?? 17.5;
    }

    // Lookup TIC for vehicles (chapter 87)
    let vehicleTicRate = 0;
    const { data: ticData } = await supabase
      .from("tic_rates")
      .select("*")
      .eq("is_active", true);
    if (ticData?.length) {
      for (const tic of ticData) {
        if ("8703".startsWith(tic.hs_code_pattern.replace(/[.\s-]/g, "").substring(0, 4)) ||
            tic.hs_code_pattern.replace(/[.\s-]/g, "").startsWith("8703")) {
          if (tic.tic_type === "ad_valorem" && tic.tic_rate) {
            vehicleTicRate = parseFloat(tic.tic_rate) * 100;
          }
          break;
        }
      }
    }

    vehicleTaxes = calculateTaxes({ caf_mad, duty_rate: vehicleDutyRate, vat_rate: 20, tic_rate: vehicleTicRate, mre_abatement: true });
    vehicleTaxesWithout = calculateTaxes({ caf_mad, duty_rate: vehicleDutyRate, vat_rate: 20, tic_rate: vehicleTicRate, mre_abatement: false });
  }

  const vehicleInfo = (import_type === "vehicle" || import_type === "both")
    ? `${vehicle_brand} ${vehicle_year}, ${vehicle_fuel}, ${vehicle_cc}cc, valeur ${vehicle_value} ${vehicle_currency}, possession: ${vehicle_ownership_months}`
    : "Pas de véhicule";

  const mreInfo = `Pays: ${residence_country}, Résidence: ${residence_years} ans, Retour: ${return_type}, Carte séjour: ${has_carte_sejour ? "Oui" : "Non"}, Cert. résidence: ${has_certificat_residence ? "Oui" : "Non"}, Cert. changement: ${has_certificat_changement ? "Oui" : "Non"}`;

  const fullContext = [legalContext, rulesContext, documentsContext, fileContext].filter(Boolean).join("\n");
  const prompt = buildMREReportPrompt(import_type, vehicleInfo, mreInfo, fullContext);
  const aiReport = await callLLM(prompt);

  return {
    ...aiReport,
    vehicle_taxes: vehicleTaxes ? {
      with_mre: vehicleTaxes,
      without_mre: vehicleTaxesWithout,
      savings: vehicleTaxesWithout ? vehicleTaxesWithout.total - vehicleTaxes.total : 0,
    } : null,
    input_summary: { import_type, vehicle: vehicleInfo, mre_situation: mreInfo },
  };
}

// ============================================================================
// CONFORMITY PROCESSOR
// ============================================================================
async function processConformityReport(supabase: any, inputs: any, fileContext: string = "") {
  const { product_description, hs_code, country_code } = inputs;

  let controlledContext = "";
  if (hs_code) {
    const prefix = hs_code.replace(/[.\s-]/g, "").substring(0, 4);
    const { data } = await supabase
      .from("controlled_products")
      .select("*")
      .ilike("hs_code", `${prefix}%`)
      .eq("is_active", true);
    if (data?.length) {
      controlledContext = data.map((c: any) =>
        `HS: ${c.hs_code} | Type: ${c.control_type} | Autorité: ${c.control_authority} | Démarche: ${JSON.stringify(c.procedure_steps)} | Délai: ${c.estimated_delay} | Coût: ${c.estimated_cost}`
      ).join("\n");
    }
  }

  // ANRT verification for conformity (approved + dispensed)
  let anrtContext = "";
  if (controlledContext.includes("ANRT") && product_description) {
    try {
      const { data: anrtResults } = await supabase
        .rpc("search_anrt_equipment", {
          p_query: product_description,
          p_limit: 5,
        });

      const { data: dispensedResults } = await supabase
        .rpc("search_anrt_dispensed_equipment", {
          search_query: product_description,
          max_results: 5,
        });

      if (anrtResults?.length) {
        anrtContext = `\n\n🔍 ÉQUIPEMENTS ANRT HOMOLOGUÉS (AGRÉÉS):\n`;
        anrtContext += anrtResults.map((r: any) =>
          `- ✅ ${r.designation} | Marque: ${r.brand} | Type: ${r.type_ref} | Modèle: ${r.model || 'N/A'} | Agrément: ${r.approval_number}`
        ).join("\n");
        anrtContext += `\nSi le produit correspond, l'homologation ANRT est DÉJÀ OBTENUE.`;
      }

      if (dispensedResults?.length) {
        anrtContext += `\n\n🔓 ÉQUIPEMENTS DISPENSÉS D'HOMOLOGATION ANRT:\n`;
        anrtContext += dispensedResults.map((r: any) =>
          `- 🔓 ${r.designation} | Marque: ${r.brand || 'N/A'} | Type/Modèle: ${r.type_model || 'N/A'} | Dispense: ${r.dispensation_number || 'N/A'}`
        ).join("\n");
        anrtContext += `\nCes équipements sont DISPENSÉS — aucune homologation ANRT requise.`;
      }

      if (!anrtResults?.length && !dispensedResults?.length) {
        anrtContext = `\n\n🔍 VÉRIFICATION ANRT: Aucun équipement trouvé dans les agréments ni les dispenses. Homologation ANRT nécessaire AVANT importation.`;
      }
    } catch (err) {
      console.error("ANRT search error:", err);
    }
  }

  // Fetch import documents for conformity
  let documentsContext = "";
  const { data: conformDocs } = await supabase
    .from("import_documents")
    .select("*")
    .eq("is_active", true)
    .order("sort_order");
  if (conformDocs?.length) {
    documentsContext = "\n\n## DOCUMENTS D'IMPORTATION REQUIS (DB)\n" + conformDocs.map((d: any) =>
      `📄 ${d.document_name_fr} | Catégorie: ${d.category} | Requis: ${d.when_required || "Toujours"} | ${d.description_fr || ""}`
    ).join("\n");
  }

  // Fetch TIC rates for conformity context
  let ticContext = "";
  if (hs_code) {
    const cleanCode = hs_code.replace(/[.\s-]/g, "");
    const { data: ticData } = await supabase
      .from("tic_rates")
      .select("*")
      .eq("is_active", true);
    if (ticData?.length) {
      for (const tic of ticData) {
        if (cleanCode.startsWith(tic.hs_code_pattern.replace(/[.\s-]/g, ""))) {
          ticContext = `\n\n## TIC APPLICABLE\n- Pattern: ${tic.hs_code_pattern} | Type: ${tic.tic_type} | Taux: ${tic.tic_rate ? (parseFloat(tic.tic_rate) * 100) + '%' : ''} | Montant: ${tic.tic_amount || 'N/A'} ${tic.tic_unit || ''} | ${tic.description_fr || ''}`;
          break;
        }
      }
    }
  }

  let legalContext = "";
  const searchTerms = ["ONSSA", "ANRT", "homologation", "conformité", "licence import"];
  for (const term of searchTerms) {
    const { data: chunks } = await supabase
      .from("legal_chunks")
      .select("chunk_text, source_id")
      .ilike("chunk_text", `%${term}%`)
      .limit(2);
    if (chunks?.length) {
      legalContext += chunks.map((c: any) => c.chunk_text.substring(0, 300)).join("\n");
    }
  }

  const fullContext = [legalContext, documentsContext, ticContext, fileContext].filter(Boolean).join("\n");
  const prompt = buildConformityReportPrompt(product_description, hs_code, country_code || "MA", controlledContext + anrtContext, fullContext);
  const aiReport = await callLLM(prompt);

  return { ...aiReport, input_summary: { product: product_description, hs_code, country: country_code } };
}

// ============================================================================
// INVESTOR PROCESSOR
// ============================================================================
async function processInvestorReport(supabase: any, inputs: any, fileContext: string = "") {
  const { sector, zone, material_description, material_hs_code, material_value, material_currency, preferred_regime } = inputs;

  const mValue = parseFloat(material_value) || 0;
  const exchangeRate = EXCHANGE_RATES[material_currency] || 10;
  const caf_mad = Math.ceil(mValue * exchangeRate);

  // Fetch full tariff context (not just duty_rate)
  let dutyRate = 2.5;
  let vatRate = 20;
  let tariffContext = "";
  if (material_hs_code) {
    const cleanCode = material_hs_code.replace(/[.\s-]/g, "");
    const code6 = cleanCode.substring(0, 6);
    const { data: tariffs } = await supabase
      .from("country_tariffs")
      .select("*")
      .eq("country_code", "MA")
      .or(`national_code.eq.${cleanCode},hs_code_6.eq.${code6}`)
      .eq("is_active", true)
      .limit(5);
    if (tariffs?.length) {
      dutyRate = tariffs[0].duty_rate ?? 2.5;
      vatRate = tariffs[0].vat_rate ?? 20;
      tariffContext = "\n\n## TARIFS DB\n" + tariffs.map((t: any) =>
        `Code: ${t.national_code || t.hs_code_6} | Désignation: ${t.description_local} | DI: ${t.duty_rate}% | TVA: ${t.vat_rate}%`
      ).join("\n");
    }
  }

  const regime_common = calculateTaxes({ caf_mad, duty_rate: dutyRate, vat_rate: vatRate });
  const regime_franchise = calculateTaxes({ caf_mad, duty_rate: 0, vat_rate: 0, tpi_rate: 0.25 });
  const regime_zone_franche = calculateTaxes({ caf_mad, duty_rate: 0, vat_rate: 0, tpi_rate: 0 });

  // Fetch trade agreements applicable
  let agreementsContext = "";
  const { data: agreements } = await supabase
    .from("trade_agreements")
    .select("code, name_fr, agreement_type, preferential_duty_rate, countries_covered, proof_required")
    .eq("is_active", true)
    .limit(10);
  if (agreements?.length) {
    agreementsContext = "\n\n## ACCORDS COMMERCIAUX DISPONIBLES\n" + agreements.map((a: any) =>
      `- ${a.name_fr} (${a.code}) | Type: ${a.agreement_type || 'N/A'} | Taux pref: ${a.preferential_duty_rate ?? 'N/A'}% | Preuve: ${a.proof_required || 'N/A'}`
    ).join("\n");
  }

  let legalContext = "";
  const { data: chunks } = await supabase.from("legal_chunks").select("chunk_text, source_id")
    .or("chunk_text.ilike.%investissement%,chunk_text.ilike.%zone franche%,chunk_text.ilike.%franchise%,chunk_text.ilike.%charte%")
    .limit(5);
  if (chunks?.length) {
    legalContext = chunks.map((c: any) => c.chunk_text.substring(0, 400)).join("\n\n");
  }

  // Fetch investor-related documents
  let documentsContext = "";
  const { data: invDocs } = await supabase
    .from("import_documents")
    .select("*")
    .eq("is_active", true)
    .or("applies_to.ilike.%investisseur%,applies_to.ilike.%all%,category.eq.investment");
  if (invDocs?.length) {
    documentsContext = "\n\n## DOCUMENTS REQUIS (DB)\n" + invDocs.map((d: any) =>
      `📄 ${d.document_name_fr} | ${d.when_required || "Toujours"} | ${d.description_fr || ""}`
    ).join("\n");
  }

  const fullContext = [legalContext, tariffContext, agreementsContext, documentsContext, fileContext].filter(Boolean).join("\n");
  const prompt = buildInvestorReportPrompt(sector, zone, material_description, `${material_value} ${material_currency}`, preferred_regime, fullContext);
  const aiReport = await callLLM(prompt);

  return {
    ...aiReport,
    regime_comparison: { droit_commun: regime_common, franchise: regime_franchise, zone_franche: regime_zone_franche, caf_mad },
    input_summary: { sector, zone, material: material_description, value: `${material_value} ${material_currency}` },
  };
}

// ============================================================================
// LLM CALL HELPER
// ============================================================================
async function callLLM(prompt: string): Promise<any> {
  const response = await fetchWithRetry(
    LOVABLE_AI_GATEWAY,
    {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: LOVABLE_AI_MODEL,
        max_tokens: 2048,
        temperature: 0.1,
        messages: [{ role: "user", content: prompt }],
      }),
    },
    {
      ...RETRY_CONFIGS.lovableAI,
      onRetry: (attempt: number, error: Error, delay: number) => {
        console.warn(`LLM retry ${attempt}: ${error.message} (wait ${delay}ms)`);
      },
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    console.error("LLM error:", response.status, errText);
    throw new Error(`LLM error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";
  const cleaned = content.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();

  try {
    return JSON.parse(cleaned);
  } catch (parseError) {
    console.error("JSON parse error:", parseError, "Content:", cleaned.substring(0, 200));
    return { raw_response: content, parse_error: true };
  }
}
