import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import {
  getCorsHeaders,
  handleCorsPreFlight,
  getClientId,
  checkRateLimitDistributed,
  rateLimitResponse,
} from "../_shared/cors.ts";

// Compute a deterministic password from server secret + email + unique salt
async function computePassword(secret: string, email: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyMaterial = `${secret}:${salt}`;
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(keyMaterial),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(email));
  const hashArray = Array.from(new Uint8Array(signature));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 40);
}

function generateSalt(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return handleCorsPreFlight(req);
  }

  const corsHeaders = getCorsHeaders(req);

  // Rate limiting: max 10 verify attempts per IP per hour
  const clientId = getClientId(req);
  const rateLimit = await checkRateLimitDistributed(clientId, {
    maxRequests: 10,
    windowMs: 60 * 60 * 1000,
    blockDurationMs: 60 * 60 * 1000,
  });

  if (!rateLimit.allowed) {
    return rateLimitResponse(req, rateLimit.resetAt);
  }

  try {
    const { email, code, displayName, skipOtp } = await req.json();

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email requis" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return new Response(
        JSON.stringify({ error: "Format d'email invalide" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Block admin accounts from using agent login flow (protects manual password)
    const { data: phoneUserCheck } = await supabase
      .from("phone_users")
      .select("auth_user_id")
      .eq("email", normalizedEmail)
      .maybeSingle();

    if (phoneUserCheck?.auth_user_id) {
      const { data: isAdmin } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", phoneUserCheck.auth_user_id)
        .eq("role", "admin")
        .maybeSingle();

      if (isAdmin) {
        return new Response(
          JSON.stringify({ error: "Ce compte utilise la connexion administrateur" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // If OTP is not skipped, validate the code
    if (!skipOtp) {
      if (!code || !/^\d{6}$/.test(code)) {
        return new Response(
          JSON.stringify({ error: "Code invalide (6 chiffres requis)" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const { data: otpRecord, error: otpError } = await supabase
        .from("otp_codes")
        .select("*")
        .eq("email", normalizedEmail)
        .eq("code", code)
        .eq("is_used", false)
        .gt("expires_at", new Date().toISOString())
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (otpError) {
        console.error("OTP lookup error:", otpError);
        return new Response(
          JSON.stringify({ error: "Erreur interne" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      if (!otpRecord) {
        const { data: latestOtp } = await supabase
          .from("otp_codes")
          .select("id, attempts")
          .eq("email", normalizedEmail)
          .eq("is_used", false)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (latestOtp) {
          const newAttempts = (latestOtp.attempts || 0) + 1;
          await supabase
            .from("otp_codes")
            .update({ attempts: newAttempts, is_used: newAttempts >= 5 })
            .eq("id", latestOtp.id);
        }

        return new Response(
          JSON.stringify({ error: "Code incorrect ou expiré" }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Mark OTP as used
      await supabase
        .from("otp_codes")
        .update({ is_used: true })
        .eq("id", otpRecord.id);
    }

    // Check if bootstrap (first user)
    const { count: totalUsers } = await supabase
      .from("phone_users")
      .select("*", { count: "exact", head: true });

    let appUser;

    if (totalUsers === 0) {
      // Bootstrap: create first manager
      const bootstrapSalt = generateSalt();
      const { data: newUser, error: createError } = await supabase
        .from("phone_users")
        .insert({
          email: normalizedEmail,
          display_name: displayName || "Manager",
          role: "agent",
          max_invites: 10,
          password_salt: bootstrapSalt,
        })
        .select()
        .single();

      if (createError) {
        console.error("Create manager error:", createError);
        return new Response(
          JSON.stringify({ error: "Erreur lors de la création du compte" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      appUser = newUser;
    } else {
      // Get existing user by email
      const { data: existingUser, error: lookupError } = await supabase
        .from("phone_users")
        .select("*")
        .eq("email", normalizedEmail)
        .maybeSingle();

      if (lookupError || !existingUser) {
        return new Response(
          JSON.stringify({ error: "Utilisateur non trouvé" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      appUser = existingUser;
    }

    // Ensure user has a unique salt
    let userSalt = appUser.password_salt;
    if (!userSalt) {
      userSalt = generateSalt();
      await supabase
        .from("phone_users")
        .update({ password_salt: userSalt })
        .eq("id", appUser.id);
    }

    // Use the real email for auth account
    const authEmail = normalizedEmail;
    const password = await computePassword(supabaseServiceKey, normalizedEmail, userSalt);

    let session;

    if (appUser.auth_user_id) {
      // User already has auth account, sign in
      const { data: signInData, error: signInError } =
        await supabase.auth.signInWithPassword({ email: authEmail, password });

      if (signInError) {
        console.error("Sign in error:", signInError);
        // Try to reset password via admin
        const { error: updateError } = await supabase.auth.admin.updateUserById(
          appUser.auth_user_id,
          { password }
        );
        if (updateError) {
          console.error("Password update error:", updateError);
          return new Response(
            JSON.stringify({ error: "Erreur de connexion" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const { data: retryData, error: retryError } =
          await supabase.auth.signInWithPassword({ email: authEmail, password });
        if (retryError) {
          console.error("Retry sign in error:", retryError);
          return new Response(
            JSON.stringify({ error: "Erreur de connexion" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        session = retryData.session;
      } else {
        session = signInData.session;
      }
    } else {
      // Try to create new auth user with real email
      const { data: createData, error: createError } =
        await supabase.auth.admin.createUser({
          email: authEmail,
          password,
          email_confirm: true,
          user_metadata: {
            email: normalizedEmail,
            display_name: appUser.display_name,
            role: appUser.role,
          },
        });

      let authUserId: string;

      if (createError) {
        // If email already exists in auth, look up and link the existing user
        if (createError.message?.includes("already been registered")) {
          console.log("Auth user already exists, linking existing account");
          const { data: listData, error: listError } = await supabase.auth.admin.listUsers();
          if (listError) {
            console.error("List users error:", listError);
            return new Response(
              JSON.stringify({ error: "Erreur lors de la création du compte" }),
              { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }
          const existingAuthUser = listData.users.find(u => u.email === normalizedEmail);
          if (!existingAuthUser) {
            return new Response(
              JSON.stringify({ error: "Erreur lors de la création du compte" }),
              { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }
          authUserId = existingAuthUser.id;
          // Update password for this user
          await supabase.auth.admin.updateUserById(authUserId, { password });
        } else {
          console.error("Create auth user error:", createError);
          return new Response(
            JSON.stringify({ error: "Erreur lors de la création du compte" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } else {
        authUserId = createData.user.id;
        // Add user_roles entry only for newly created users
        await supabase.from("user_roles").insert({
          user_id: authUserId,
          role: appUser.role,
        });
      }

      // Link auth user to app user record
      await supabase
        .from("phone_users")
        .update({ auth_user_id: authUserId })
        .eq("id", appUser.id);

      // Sign in to get session
      const { data: signInData, error: signInError } =
        await supabase.auth.signInWithPassword({ email: authEmail, password });

      if (signInError) {
        console.error("Post-create sign in error:", signInError);
        return new Response(
          JSON.stringify({ error: "Compte créé mais erreur de connexion" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      session = signInData.session;
    }

    if (!session) {
      return new Response(
        JSON.stringify({ error: "Erreur de session" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        session: {
          access_token: session.access_token,
          refresh_token: session.refresh_token,
          expires_in: session.expires_in,
        },
        user: {
          id: appUser.id,
          email: appUser.email,
          display_name: appUser.display_name,
          role: appUser.role,
        },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("verify-otp error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Erreur inconnue" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
